package com.cmpe281.team12.ccrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CcrsApplicationTests {
/*
	@Test
	void contextLoads() {
	}
*/
}
