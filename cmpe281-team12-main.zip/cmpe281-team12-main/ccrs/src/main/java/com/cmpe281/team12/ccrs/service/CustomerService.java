package com.cmpe281.team12.ccrs.service;

import java.util.List;
import java.util.Map;

public interface CustomerService {
    List<Map<String,String>> getActiveAccountLocations();
}
