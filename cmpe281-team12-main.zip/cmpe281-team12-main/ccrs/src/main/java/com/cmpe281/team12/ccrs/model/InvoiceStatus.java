package com.cmpe281.team12.ccrs.model;

public enum InvoiceStatus {
    OPEN, PAID
}
