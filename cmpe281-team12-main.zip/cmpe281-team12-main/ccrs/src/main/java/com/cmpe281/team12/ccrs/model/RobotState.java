package com.cmpe281.team12.ccrs.model;

public enum RobotState {
    CREATED, ENABLED, RUNNING, PAUSED, TERMINATED
}
