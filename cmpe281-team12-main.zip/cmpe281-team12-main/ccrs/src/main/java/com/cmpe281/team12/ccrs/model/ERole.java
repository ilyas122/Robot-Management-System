package com.cmpe281.team12.ccrs.model;

public enum ERole {
    ROLE_CUSTOMER,
    ROLE_BUSINESS,
    ROLE_ADMIN
}