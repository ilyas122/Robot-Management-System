import React, { Component } from "react";

export default class Signup extends Component {
    render() {
        return (
            <p> signup </p>
        );
    }
}
