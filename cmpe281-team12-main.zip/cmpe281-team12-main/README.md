# cmpe281-team12

## Meeting Notes
https://docs.google.com/document/d/1Gn7Rywbop9HJlYNVRU5Ghbgue60N4v79znte2CvsaPc/edit?usp=sharing

## Diagram
https://drive.google.com/file/d/1OrutmUjmpGIdP9m2xy6FyL7VXXSQ5h09/view?usp=sharing

## Frontend npm
 npm install react-router-dom@5.2.0

 create blank application
npx create-react-app customer-ui
2. move all code in github src/*
3.  type this commend
npm install
npm start
you got some error: module 'router' cannot find , you can type to install module
npm install react-router-dom@5.2.0
Whenever you face error module, search google, and then install
npm start => type to run application
