package cmpe.cloudcomputing.robot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RobotApplicationTests {

	@Test
	void contextLoads() {
	}

}
