const CONSTANTS = {
    API_URL: "http://localhost:8080/ccrs",

}

export default CONSTANTS;